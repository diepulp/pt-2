---
name: performance-engineer
description: PT-2 performance engineering specialist for Supabase (Postgres/RLS/RPC) and API endpoints. This skill should be used when analyzing query performance, setting SLO targets, building benchmark harnesses, creating CI performance gates, or investigating latency regressions. Produces EXPLAIN ANALYZE reports, index recommendations, and performance dashboards.
allowed-tools: Read, Write, Edit, Glob, Grep, Bash, TodoWrite, Task, WebFetch
---

# Performance Engineer

PT-2 performance engineering specialist owning latency budgets, regression prevention, and query optimization for Supabase (Postgres/RLS/RPC) and Next.js API endpoints.

## Quick Reference

| Task | Command |
|------|---------|
| Analyze slow query | `scripts/query_analyzer.py --sql "SELECT..." --conn $DATABASE_URL` |
| Run benchmark suite | `scripts/benchmark.py --suite api --baseline main` |
| CI regression gate | `scripts/ci_gate.py --threshold 10 --baseline .perf/baseline.json` |
| Generate report | `scripts/benchmark.py --report --output perf-report.md` |

## When to Invoke This Skill

- Investigating slow API endpoints or database queries
- Setting up SLO targets for new endpoints
- Creating benchmark baselines before optimization
- Adding CI gates to prevent performance regressions
- Analyzing EXPLAIN plans and recommending indexes
- Auditing RLS policy overhead
- Reviewing connection pooling behavior

## Core Workflows

### 1. Query Performance Investigation

To investigate a slow query or endpoint:

1. **Capture baseline metrics** using the benchmark harness
2. **Run EXPLAIN ANALYZE** on suspected slow queries
3. **Analyze the query plan** for sequential scans, high row estimates, or nested loops
4. **Check RLS overhead** by comparing with/without policy enforcement
5. **Recommend fixes** (indexes, query rewrites, caching)

```bash
# Analyze a specific query
python scripts/query_analyzer.py \
  --sql "SELECT * FROM visits WHERE player_id = $1" \
  --params '["uuid-here"]' \
  --conn "$DATABASE_URL"
```

**Output includes:**
- Execution time breakdown (planning vs execution)
- Row estimates vs actual rows
- Index usage and sequential scan detection
- Buffer cache hit ratio
- Recommendations based on plan analysis

### 2. Benchmark Harness

To establish performance baselines and detect regressions:

```bash
# Run full benchmark suite
python scripts/benchmark.py --suite all

# Run specific suite (api, db, e2e)
python scripts/benchmark.py --suite api --iterations 10

# Compare against baseline
python scripts/benchmark.py --suite api --baseline .perf/baseline.json

# Generate markdown report
python scripts/benchmark.py --report --output perf-report.md
```

**Benchmark suites:**
- `api`: API endpoint latency (p50/p95/p99)
- `db`: Database query performance (SQL, RPC, PostgREST)
- `e2e`: Critical user flows (slip lifecycle, player search)

### 3. CI Performance Gate

To prevent performance regressions in CI:

```bash
# Add to CI pipeline
python scripts/ci_gate.py \
  --baseline .perf/baseline.json \
  --threshold 10 \
  --fail-on-regression
```

**Gate behavior:**
- Fails build if p95 latency increases >10% from baseline
- Fails build if any endpoint exceeds SLO target
- Generates diff report showing regressions

### 4. SLO Definition

To define performance targets for endpoints:

1. Read `references/slo-definitions.md` for standard targets
2. Categorize endpoint by type (read-heavy, write-heavy, aggregation)
3. Set appropriate p50/p95/p99 targets
4. Add endpoint to benchmark suite
5. Configure CI gate thresholds

**Standard SLO tiers:**

| Tier | p50 | p95 | p99 | Use Case |
|------|-----|-----|-----|----------|
| Fast | <50ms | <100ms | <200ms | Simple reads, cached data |
| Standard | <100ms | <250ms | <500ms | CRUD operations, joins |
| Complex | <250ms | <500ms | <1000ms | Aggregations, reports |
| Background | <1000ms | <2000ms | <5000ms | Batch operations |

## KPI Dashboard

Track these metrics for system health:

### API Endpoint KPIs
- **Latency**: p50 / p95 / p99 response times
- **Error rate**: % non-2xx responses, timeouts
- **Throughput**: max sustainable RPS at target p95
- **DB time ratio**: DB time / total time

### Supabase/Postgres KPIs
- **Query execution time**: distribution across percentiles
- **Selectivity**: rows scanned vs rows returned
- **Cache hit ratio**: buffer cache effectiveness
- **Lock waits / deadlocks**: contention indicators
- **RLS overhead**: policy enforcement cost
- **Connection pool saturation**: queued requests, latency spikes

### End-to-End Flow KPIs
- **Slip lifecycle**: open → update → close path latency
- **Player search**: search → open visit → view ledger flow
- **Table operations**: table assignment, player movement

## Performance Review Checklist

For PR reviews involving database or API changes:

- [ ] New queries have EXPLAIN ANALYZE output attached
- [ ] Indexes exist for WHERE/JOIN columns
- [ ] No N+1 query patterns introduced
- [ ] RLS policies use indexed predicates
- [ ] Benchmark results show no p95 regression >10%
- [ ] Connection pooling implications considered
- [ ] Batch operations preferred over loops

See `references/pr-checklist.md` for detailed checklist.

## Resources

### scripts/

| Script | Purpose |
|--------|---------|
| `benchmark.py` | Main benchmarking harness for API, DB, and E2E tests |
| `query_analyzer.py` | EXPLAIN ANALYZE wrapper with recommendations |
| `ci_gate.py` | CI integration for regression prevention |

### references/

| Reference | Purpose |
|-----------|---------|
| `slo-definitions.md` | Standard SLO targets by endpoint type |
| `query-patterns.md` | Query optimization patterns and anti-patterns |
| `rls-performance.md` | RLS-specific performance considerations |
| `pr-checklist.md` | Detailed PR performance review checklist |

## Memory Recording Protocol

This skill tracks execution outcomes to build performance pattern knowledge.

### Record Performance Analysis

```python
from lib.memori import create_memori_client, SkillContext

memori = create_memori_client("skill:performance-engineer")
memori.enable()
context = SkillContext(memori)

context.record_skill_execution(
    skill_name="performance-engineer",
    task="Query optimization for visits table",
    outcome="success",
    pattern_used="Index addition + query rewrite",
    validation_results={
        "p95_before_ms": 450,
        "p95_after_ms": 85,
        "improvement_pct": 81
    },
    files_created=["supabase/migrations/xxx_add_visits_index.sql"],
    lessons_learned=["Composite index on (casino_id, player_id) critical for RLS"]
)
```

### Query Past Optimizations

```python
past_optimizations = memori.search_learnings(
    query="query optimization RLS",
    tags=["performance", "rls", "indexing"],
    category="skills",
    limit=5
)
```

## Top 10 Expensive Queries

Maintain a living document of the most expensive queries:

```sql
-- Query the pg_stat_statements extension
SELECT
  query,
  calls,
  mean_exec_time,
  total_exec_time,
  rows
FROM pg_stat_statements
ORDER BY mean_exec_time DESC
LIMIT 10;
```

Update `docs/50-ops/TOP_10_QUERIES.md` weekly with current offenders.
