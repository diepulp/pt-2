#!/usr/bin/env python3
"""
PT-2 CI Performance Gate

Prevents performance regressions by comparing current benchmark results against baseline.
Designed for integration with GitHub Actions or other CI systems.

Usage:
    python ci_gate.py --baseline .perf/baseline.json --threshold 10
    python ci_gate.py --baseline .perf/baseline.json --fail-on-regression

Exit codes:
    0 - All checks passed
    1 - Performance regressions detected
    2 - Configuration or runtime error
"""

import argparse
import json
import os
import sys
from dataclasses import dataclass
from datetime import datetime
from pathlib import Path
from typing import Optional


@dataclass
class GateResult:
    """Result of a performance gate check."""
    name: str
    metric: str
    current_value: float
    baseline_value: float
    threshold_pct: float
    diff_pct: float
    passed: bool
    reason: str


@dataclass
class GateSummary:
    """Summary of all gate checks."""
    total_checks: int
    passed_checks: int
    failed_checks: int
    regressions: list[GateResult]
    improvements: list[GateResult]
    overall_passed: bool


def load_json(path: str) -> dict:
    """Load JSON file with error handling."""
    try:
        with open(path) as f:
            return json.load(f)
    except FileNotFoundError:
        print(f"ERROR: File not found: {path}", file=sys.stderr)
        sys.exit(2)
    except json.JSONDecodeError as e:
        print(f"ERROR: Invalid JSON in {path}: {e}", file=sys.stderr)
        sys.exit(2)


def compare_results(
    current: dict,
    baseline: dict,
    threshold_pct: float = 10.0,
    metrics: list[str] = ["p95_ms"]
) -> GateSummary:
    """Compare current results against baseline."""
    results: list[GateResult] = []

    # Build lookup for baseline results
    baseline_by_name = {r["name"]: r for r in baseline.get("results", [])}

    for result in current.get("results", []):
        name = result["name"]
        if name not in baseline_by_name:
            continue

        baseline_result = baseline_by_name[name]

        for metric in metrics:
            if metric not in result or metric not in baseline_result:
                continue

            current_val = result[metric]
            baseline_val = baseline_result[metric]

            if baseline_val == 0:
                diff_pct = 0 if current_val == 0 else float('inf')
            else:
                diff_pct = ((current_val - baseline_val) / baseline_val) * 100

            passed = diff_pct <= threshold_pct

            if diff_pct > threshold_pct:
                reason = f"Regression: {diff_pct:+.1f}% exceeds {threshold_pct}% threshold"
            elif diff_pct < -threshold_pct:
                reason = f"Improvement: {diff_pct:+.1f}%"
            else:
                reason = f"Within threshold: {diff_pct:+.1f}%"

            results.append(GateResult(
                name=name,
                metric=metric,
                current_value=current_val,
                baseline_value=baseline_val,
                threshold_pct=threshold_pct,
                diff_pct=diff_pct,
                passed=passed,
                reason=reason
            ))

    regressions = [r for r in results if not r.passed]
    improvements = [r for r in results if r.diff_pct < -threshold_pct]

    return GateSummary(
        total_checks=len(results),
        passed_checks=len([r for r in results if r.passed]),
        failed_checks=len(regressions),
        regressions=regressions,
        improvements=improvements,
        overall_passed=len(regressions) == 0
    )


def generate_github_summary(summary: GateSummary) -> str:
    """Generate GitHub Actions step summary."""
    lines = [
        "## Performance Gate Results",
        "",
        f"**Status**: {'PASSED' if summary.overall_passed else 'FAILED'}",
        f"**Checks**: {summary.passed_checks}/{summary.total_checks} passed",
        ""
    ]

    if summary.regressions:
        lines.extend([
            "### Regressions Detected",
            "",
            "| Endpoint | Metric | Current | Baseline | Diff |",
            "|----------|--------|---------|----------|------|"
        ])
        for r in summary.regressions:
            lines.append(
                f"| {r.name} | {r.metric} | {r.current_value:.1f}ms | "
                f"{r.baseline_value:.1f}ms | {r.diff_pct:+.1f}% |"
            )
        lines.append("")

    if summary.improvements:
        lines.extend([
            "### Improvements",
            "",
            "| Endpoint | Metric | Current | Baseline | Diff |",
            "|----------|--------|---------|----------|------|"
        ])
        for r in summary.improvements:
            lines.append(
                f"| {r.name} | {r.metric} | {r.current_value:.1f}ms | "
                f"{r.baseline_value:.1f}ms | {r.diff_pct:+.1f}% |"
            )

    return "\n".join(lines)


def generate_console_report(summary: GateSummary) -> str:
    """Generate console-friendly report."""
    lines = [
        "",
        "=" * 60,
        "PERFORMANCE GATE RESULTS",
        "=" * 60,
        "",
        f"Status: {'PASSED' if summary.overall_passed else 'FAILED'}",
        f"Checks: {summary.passed_checks}/{summary.total_checks} passed",
        ""
    ]

    if summary.regressions:
        lines.append("REGRESSIONS:")
        for r in summary.regressions:
            lines.append(
                f"  {r.name} ({r.metric}): "
                f"{r.baseline_value:.1f}ms -> {r.current_value:.1f}ms "
                f"({r.diff_pct:+.1f}%)"
            )
        lines.append("")

    if summary.improvements:
        lines.append("IMPROVEMENTS:")
        for r in summary.improvements:
            lines.append(
                f"  {r.name} ({r.metric}): "
                f"{r.baseline_value:.1f}ms -> {r.current_value:.1f}ms "
                f"({r.diff_pct:+.1f}%)"
            )
        lines.append("")

    lines.append("=" * 60)

    return "\n".join(lines)


def main():
    parser = argparse.ArgumentParser(description="PT-2 CI Performance Gate")
    parser.add_argument("--current", type=str, default=".perf/current.json",
                        help="Path to current benchmark results")
    parser.add_argument("--baseline", type=str, required=True,
                        help="Path to baseline benchmark results")
    parser.add_argument("--threshold", type=float, default=10.0,
                        help="Regression threshold percentage (default: 10)")
    parser.add_argument("--metrics", type=str, default="p95_ms",
                        help="Comma-separated metrics to check")
    parser.add_argument("--fail-on-regression", action="store_true",
                        help="Exit with error code on regression")
    parser.add_argument("--github-summary", type=str,
                        help="Write GitHub Actions step summary to file")
    parser.add_argument("--output", type=str,
                        help="Write detailed report to file")

    args = parser.parse_args()

    # Load data
    current = load_json(args.current)
    baseline = load_json(args.baseline)

    # Parse metrics
    metrics = [m.strip() for m in args.metrics.split(",")]

    # Compare
    summary = compare_results(
        current=current,
        baseline=baseline,
        threshold_pct=args.threshold,
        metrics=metrics
    )

    # Generate reports
    console_report = generate_console_report(summary)
    print(console_report)

    if args.github_summary:
        github_report = generate_github_summary(summary)
        Path(args.github_summary).parent.mkdir(parents=True, exist_ok=True)
        with open(args.github_summary, "w") as f:
            f.write(github_report)
        print(f"\nGitHub summary written to: {args.github_summary}")

    if args.output:
        with open(args.output, "w") as f:
            f.write(console_report)
        print(f"Report written to: {args.output}")

    # Set GitHub Actions output if running in CI
    github_output = os.environ.get("GITHUB_OUTPUT")
    if github_output:
        with open(github_output, "a") as f:
            f.write(f"passed={str(summary.overall_passed).lower()}\n")
            f.write(f"regressions={summary.failed_checks}\n")

    # Exit code
    if args.fail_on_regression and not summary.overall_passed:
        sys.exit(1)

    sys.exit(0)


if __name__ == "__main__":
    main()
