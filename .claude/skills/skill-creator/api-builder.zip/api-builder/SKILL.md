---
name: api-builder
description: Build and maintain API/DATA artifacts for PT-2 architecture. This skill should be used when creating OpenAPI specifications, Zod schema DTOs, contract-first API endpoints, event catalogs, or validating API surface compliance with SRM contracts. Use for implementing Route Handlers, Server Actions, and service layer HTTP integrations following SDLC taxonomy API/DATA patterns.
allowed-tools: Read, Write, Edit, Glob, Bash, Grep, TodoWrite, mcp__serena__*
---

# API Builder

Build contract-first API surfaces aligned with PT-2 SDLC taxonomy.

## SDLC Taxonomy Reference

This skill implements the **API/DATA** category from `docs/patterns/SDLC_DOCS_TAXONOMY.md`:

**What:** OpenAPI/Swagger, contract-first DTOs + shared zod schemas, DB schema (`database.types.ts`), events
**Why:** Stable interfaces for client/server and data lineage; keeps UI/tests aligned with SRM DTOs
**Docs:** API Surface, DTO Catalog (edge/server), Event Catalog, Schema Diffs, Migration Plan

**Canonical References (load as needed):**
- `docs/25-api-data/API_SURFACE_MVP.md` - ServiceHttpResult envelope, route patterns
- `docs/25-api-data/DTO_CATALOG.md` - DTO definitions by bounded context
- `docs/25-api-data/DTO_CANONICAL_STANDARD.md` - Pattern A/B/C type derivation rules
- `docs/25-api-data/REAL_TIME_EVENTS_MAP.md` - Event contracts
- `docs/20-architecture/SERVICE_LAYER_ARCHITECTURE_DIAGRAM.md` - Service structure

---

## Memory Recording Protocol 🧠

This skill tracks execution outcomes to build API design pattern knowledge and improve over time.

### Memory Activation Model

Memory is **automatically activated** when this skill is invoked via the `Skill` tool.

**How automatic activation works:**
1. `PreToolUse` hook detects `Skill` tool invocation
2. `skill-init-memori.sh` extracts skill name and initializes namespace
3. Memori client is enabled for `skill_api_builder` namespace
4. All subsequent `record_memory()` calls in this session use the skill namespace

**Automatic activation points:**
- ✅ Skill invocation via `Skill` tool - **auto-enabled via hook**

**Manual activation** (if needed outside skill invocation):

```python
from lib.memori import create_memori_client, SkillContext

memori = create_memori_client("skill:api-builder")
memori.enable()  # Required for manual initialization
context = SkillContext(memori)
```

### Skill Execution Tracking

Record complete execution outcomes after API implementation:

```python
from lib.memori import create_memori_client, SkillContext

memori = create_memori_client("skill:api-builder")
memori.enable()
context = SkillContext(memori)

# Record API implementation outcome
context.record_skill_execution(
    skill_name="api-builder",
    task="Create Player API endpoints",
    outcome="success",  # or "failure", "partial"
    pattern_used="Pattern B (Canonical) + Route Handler + React Query integration",
    validation_results={
        "zod_schemas_valid": True,
        "dto_pattern_compliance": "Pattern B - Pick/Omit",
        "srm_alignment": "PlayerService DTOs verified",
        "idempotency_implemented": True,
        "service_http_result_used": True
    },
    files_created=[
        "app/api/v1/players/route.ts",
        "app/api/v1/players/[player_id]/route.ts",
        "services/player/dtos.ts",
        "services/player/http.ts"
    ],
    issues_encountered=[
        "Initial DTO used interface instead of type alias (fixed)",
        "Missing idempotency-key header enforcement (added)"
    ],
    lessons_learned=[
        "Always check SRM for bounded context ownership before creating DTOs",
        "Route handlers must use ServiceHttpResult envelope"
    ]
)
```

### Query Past API Patterns Before Starting

Before creating new API endpoints, check what patterns worked before:

```python
past_apis = memori.search_learnings(
    query="API endpoint implementation route handler",
    tags=["api-implementation", "route-handler", "dto"],
    category="skills",
    limit=5
)

if past_apis:
    print(f"\n📚 Learning from {len(past_apis)} past API implementations:\n")
    for api in past_apis:
        metadata = api.get('metadata', {})
        print(f"  Task: {metadata.get('task', 'N/A')}")
        print(f"  Pattern Used: {metadata.get('pattern_used', 'N/A')}")
        print(f"  Outcome: {metadata.get('outcome', 'N/A')}")
```

### Namespace Reference

The skill uses the namespace `skill_api_builder` in the database. This maps from:
- Client initialization: `create_memori_client("skill:api-builder")`
- Database user_id: `skill_api_builder`

---

## Context Threshold Management 📊

This skill is designed for long-running API implementation sessions. When context usage approaches **60%** of the context window, the skill proactively manages session continuity.

### Context Awareness Protocol

**Monitor context usage throughout the session.** When you estimate context is approaching 60%:

1. **Announce threshold reached:**
   ```
   ⚠️ Context Usage Alert: Approaching 60% threshold.
   Recommend saving checkpoint before /clear to preserve session state.
   ```

2. **Save checkpoint before /clear:**
   ```python
   from lib.memori import create_memori_client, SkillContext

   memori = create_memori_client("skill:api-builder")
   memori.enable()
   context = SkillContext(memori)

   context.save_checkpoint(
       current_task="[Current API implementation task]",
       reason="context_threshold_60pct",
       decisions_made=["DTO pattern selected", "Route structure defined"],
       files_modified=["route.ts", "dtos.ts", "http.ts"],
       open_questions=["Outstanding API design question?"],
       next_steps=["Implement remaining endpoints", "Add validation"],
       key_insights=["Key learning from session"],
       workflow="api-builder",
       notes="Additional context for resume"
   )
   ```

3. **Inform user and recommend /clear:**
   ```
   ✅ Checkpoint saved. Session state persisted to Memori.

   You can now run /clear to reset context. After clearing:
   - Run `/api-checkpoint restore` to resume from checkpoint
   - Or start fresh with new context
   ```

### Post-Clear Session Resume

After `/clear`, restore session context immediately:

```python
from lib.memori import create_memori_client, SkillContext

memori = create_memori_client("skill:api-builder")
memori.enable()
context = SkillContext(memori)

# Load and display formatted checkpoint
resume_context = context.format_checkpoint_for_resume()
print(resume_context)
```

### Slash Command Reference

- **`/api-checkpoint save`** - Save current session state before /clear
- **`/api-checkpoint restore`** - Resume from last checkpoint after /clear

---

## Workflow Decision Tree

```
API Implementation Request
│
├─ What type of API artifact?
│   ├─ Route Handler (GET/POST/PATCH/DELETE) → [Route Handler Workflow]
│   ├─ Server Action (form submission) → [Server Action Workflow]
│   ├─ DTO Definition → [DTO Pattern Selection]
│   ├─ Zod Schema → [Schema Definition Workflow]
│   ├─ Event Contract → [Event Catalog Workflow]
│   └─ OpenAPI Spec → [OpenAPI Generation Workflow]
│
├─ Which bounded context?
│   ├─ Foundational: Casino → SRM §CasinoService
│   ├─ Identity: Player → SRM §PlayerService
│   ├─ Operational: Visit, TableContext, FloorLayout → SRM §respective
│   ├─ Telemetry: RatingSlip → SRM §RatingSlipService
│   ├─ Reward: Loyalty → SRM §LoyaltyService
│   ├─ Finance: PlayerFinancial → SRM §PlayerFinancialService
│   └─ Compliance: MTL → SRM §MTLService
│
└─ DTO Pattern Required?
    ├─ Simple CRUD (Player, Visit, Casino, FloorLayout) → Pattern B (Canonical)
    ├─ Complex (Loyalty, Finance, MTL, TableContext) → Pattern A (Contract-First)
    └─ Mixed (RatingSlip) → Pattern C (Hybrid)
```

---

## Route Handler Workflow

### Step 1: Verify SRM Ownership

Before creating any endpoint, verify bounded context ownership:

```bash
# Search SRM for service ownership
grep -n "OWNS:" docs/20-architecture/SERVICE_RESPONSIBILITY_MATRIX.md
```

**Rule**: Only the owning service can write to its tables. Cross-context access must use published DTOs.

### Step 2: Create Zod Schemas

Define request/response schemas in the service directory:

```typescript
// services/player/schemas.ts
import { z } from 'zod';

// Request params (path parameters)
export const PlayerDetailParamsSchema = z.object({
  player_id: z.string().uuid(),
});

// Request body (POST/PATCH)
export const PlayerCreateSchema = z.object({
  first_name: z.string().min(1),
  last_name: z.string().min(1),
  birth_date: z.string().optional(),
});

// Query parameters (GET list)
export const PlayerListQuerySchema = z.object({
  casino_id: z.string().uuid(),
  q: z.string().optional(),
  cursor: z.string().optional(),
  limit: z.number().int().min(1).max(100).optional(),
});

// Response DTO (derived from Database types - Pattern B)
export const PlayerSchema = z.object({
  id: z.string().uuid(),
  first_name: z.string(),
  last_name: z.string(),
  birth_date: z.string().nullable(),
  created_at: z.string(),
});
```

### Step 3: Create DTOs

Select pattern based on service complexity:

**Pattern B (Canonical) - Player, Visit, Casino, FloorLayout:**
```typescript
// services/player/dtos.ts
import type { Database } from '@/types/database.types';

/**
 * PlayerDTO - Public player profile
 *
 * Exposure: UI, external APIs
 * Excludes: birth_date (PII), internal_notes (staff-only)
 * Owner: PlayerService (SRM:149)
 */
export type PlayerDTO = Pick<
  Database['public']['Tables']['player']['Row'],
  'id' | 'first_name' | 'last_name' | 'created_at'
>;

export type PlayerCreateDTO = Pick<
  Database['public']['Tables']['player']['Insert'],
  'first_name' | 'last_name' | 'birth_date'
>;
```

**Pattern A (Contract-First) - Loyalty, Finance, MTL, TableContext:**
```typescript
// services/loyalty/dtos.ts

/**
 * PlayerLoyaltyDTO - Public loyalty balance
 *
 * Exposure: UI, external APIs
 * Excludes: preferences (internal-only)
 * Owner: LoyaltyService (SRM:343-373)
 */
export interface PlayerLoyaltyDTO {
  player_id: string;
  casino_id: string;
  balance: number;
  tier: string | null;
}

// REQUIRED: mappers.ts for Pattern A
// services/loyalty/mappers.ts
import type { Database } from '@/types/database.types';
type LoyaltyRow = Database['public']['Tables']['player_loyalty']['Row'];

export function toPlayerLoyaltyDTO(row: LoyaltyRow): PlayerLoyaltyDTO {
  return {
    player_id: row.player_id,
    casino_id: row.casino_id,
    balance: row.balance,
    tier: row.tier,
    // Explicitly omit: preferences
  };
}
```

### Step 4: Implement Route Handler

```typescript
// app/api/v1/players/route.ts
import { NextRequest, NextResponse } from 'next/server';
import { createClient } from '@/lib/supabase/server';
import { createPlayerService } from '@/services/player';
import { PlayerCreateSchema, PlayerListQuerySchema } from '@/services/player/schemas';
import { successResponse, errorResponse } from '@/lib/http/service-response';

export async function GET(request: NextRequest) {
  const { searchParams } = new URL(request.url);

  // Validate query params
  const queryResult = PlayerListQuerySchema.safeParse({
    casino_id: searchParams.get('casino_id'),
    q: searchParams.get('q'),
    cursor: searchParams.get('cursor'),
    limit: searchParams.get('limit') ? Number(searchParams.get('limit')) : undefined,
  });

  if (!queryResult.success) {
    return errorResponse({
      code: 'VALIDATION_ERROR',
      message: 'Invalid query parameters',
      details: queryResult.error.issues,
      status: 400,
    });
  }

  const supabase = await createClient();
  const service = createPlayerService(supabase);
  const result = await service.list(queryResult.data);

  return result.success
    ? successResponse(result)
    : errorResponse(result);
}

export async function POST(request: NextRequest) {
  // Enforce idempotency for mutations
  const idempotencyKey = request.headers.get('x-idempotency-key');
  if (!idempotencyKey) {
    return errorResponse({
      code: 'IDEMPOTENCY_KEY_REQUIRED',
      message: 'x-idempotency-key header is required for mutations',
      status: 400,
    });
  }

  const body = await request.json();
  const parseResult = PlayerCreateSchema.safeParse(body);

  if (!parseResult.success) {
    return errorResponse({
      code: 'VALIDATION_ERROR',
      message: 'Invalid request body',
      details: parseResult.error.issues,
      status: 400,
    });
  }

  const supabase = await createClient();
  const service = createPlayerService(supabase);
  const result = await service.create(parseResult.data, { idempotencyKey });

  return result.success
    ? successResponse(result, 201)
    : errorResponse(result);
}
```

### Step 5: Create HTTP Fetchers

```typescript
// services/player/http.ts
import { fetchJSON } from '@/lib/http/fetch-json';
import type { PlayerDTO, PlayerCreateDTO } from './dtos';

export async function getPlayer(id: string): Promise<PlayerDTO> {
  return fetchJSON(`/api/v1/players/${id}`);
}

export async function createPlayer(input: PlayerCreateDTO): Promise<PlayerDTO> {
  return fetchJSON('/api/v1/players', {
    method: 'POST',
    headers: {
      'content-type': 'application/json',
      'x-idempotency-key': crypto.randomUUID(),
    },
    body: JSON.stringify(input),
  });
}
```

### Step 6: Create Query Key Factory

```typescript
// services/player/keys.ts
type PlayerListFilters = {
  status?: 'active' | 'inactive';
  q?: string;
  casinoId?: string;
};

const serialize = (filters: PlayerListFilters = {}) =>
  JSON.stringify(
    Object.keys(filters)
      .sort()
      .map((key) => [key, filters[key as keyof PlayerListFilters]])
  );

export const playerKeys = {
  root: ['player'] as const,

  list: Object.assign(
    (filters: PlayerListFilters = {}) =>
      [...playerKeys.root, 'list', serialize(filters)] as const,
    {
      scope: [...playerKeys.root, 'list'] as const,
    }
  ),

  detail: (id: string) =>
    [...playerKeys.root, 'detail', id] as const,

  create: () => [...playerKeys.root, 'create'] as const,
};
```

---

## ServiceHttpResult Envelope

All API responses MUST use the canonical envelope:

```typescript
// Internal: Service Layer → Route Handler
interface ServiceResult<T> {
  data: T | null;
  error: ServiceError | null;
  success: boolean;
  timestamp: string;
  requestId: string;
}

// External: Route Handler → Client
interface ServiceHttpResult<T> {
  ok: boolean;           // Maps from success
  code: string;          // Domain error code
  status: number;        // HTTP status
  requestId: string;     // Passthrough
  durationMs: number;    // Added by wrapper
  timestamp: string;     // Passthrough
  data?: T;              // Optional
  error?: string;        // Optional
  details?: unknown;     // Optional
}
```

**Response helpers:**
```typescript
// lib/http/service-response.ts
export function successResponse<T>(
  result: ServiceResult<T>,
  status: number = 200
): NextResponse {
  return NextResponse.json({
    ok: true,
    code: 'OK',
    status,
    requestId: result.requestId,
    durationMs: calculateDuration(result.timestamp),
    timestamp: result.timestamp,
    data: result.data,
  }, { status });
}

export function errorResponse(result: ServiceResult<unknown>): NextResponse {
  const httpStatus = mapToHttpStatus(result.error?.code);
  return NextResponse.json({
    ok: false,
    code: result.error?.code || 'INTERNAL_ERROR',
    status: httpStatus,
    requestId: result.requestId,
    durationMs: calculateDuration(result.timestamp),
    timestamp: result.timestamp,
    error: result.error?.message,
    details: result.error?.details,
  }, { status: httpStatus });
}
```

---

## Error Code Mapping

| PostgreSQL | PostgREST | Domain Code | HTTP |
|------------|-----------|-------------|------|
| 23505 | - | UNIQUE_VIOLATION | 409 |
| 23503 | - | FOREIGN_KEY_VIOLATION | 400 |
| 23514 | - | VALIDATION_ERROR | 400 |
| 23502 | - | VALIDATION_ERROR | 400 |
| - | PGRST116 | NOT_FOUND | 404 |
| - | - | UNAUTHORIZED | 401 |
| - | - | FORBIDDEN | 403 |
| - | - | TIMEOUT | 504 |
| - | - | INTERNAL_ERROR | 500 |

---

## Idempotency Implementation

### Required for All Mutations

```typescript
// Route layer: Enforce header
const idempotencyKey = request.headers.get('x-idempotency-key');
if (!idempotencyKey) {
  return errorResponse({
    code: 'IDEMPOTENCY_KEY_REQUIRED',
    status: 400,
  });
}

// Service layer: Check and store
async create(data: CreateDTO, opts?: { idempotencyKey?: string }) {
  if (opts?.idempotencyKey) {
    // Check existing
    const { data: existing } = await this.supabase
      .from('table')
      .select('*')
      .eq('idempotency_key', opts.idempotencyKey)
      .single();

    if (existing) return existing; // Idempotent return
  }

  // Insert with idempotency key
  return this.supabase.from('table').insert({
    ...data,
    idempotency_key: opts?.idempotencyKey
  });
}
```

### Database Schema

```sql
-- Partial unique index for idempotency
CREATE UNIQUE INDEX ux_table_idem
  ON table_name (idempotency_key)
  WHERE idempotency_key IS NOT NULL;
```

---

## Event Catalog Pattern

For real-time events, define contracts in the event catalog:

```typescript
// Real-time event contract
interface RatingSlipUpdatedEvent {
  event: 'rating_slip.updated';
  rating_slip_id: string;
  player_id: string;
  casino_id: string;
  average_bet: number;
  minutes_played: number;
  game_type: 'blackjack' | 'poker' | 'roulette' | 'baccarat';
  at: string; // ISO timestamp
}

// Event-to-cache mapping
const EVENT_CACHE_MAP = {
  'rating_slip.updated': {
    queryKeys: ['ratingSlipKeys.detail(id)', 'ratingSlipKeys.list.scope'],
    operation: 'setQueryData + invalidate',
  },
  'loyalty.ledger_appended': {
    queryKeys: ['loyaltyKeys.ledger(playerId)'],
    operation: 'invalidate',
  },
};
```

---

## Validation Checklist

Before completing API implementation:

- [ ] SRM ownership verified for bounded context
- [ ] DTO pattern selected (A/B/C) based on service type
- [ ] Zod schemas defined for request/response
- [ ] Route handler uses ServiceHttpResult envelope
- [ ] Idempotency enforced for mutations (x-idempotency-key)
- [ ] HTTP fetchers created in `services/{domain}/http.ts`
- [ ] Query key factory created in `services/{domain}/keys.ts`
- [ ] Error mapping implemented (PG → HTTP)
- [ ] Rate limiting configured per route
- [ ] Audit logging via withServerAction wrapper
- [ ] Cross-context access uses published DTOs only
- [ ] No manual interfaces for Pattern B services

---

## References

Load these documents as needed during implementation:

### Core References
- `references/api-surface-patterns.md` - Complete route handler templates
- `references/dto-patterns.md` - Pattern A/B/C examples
- `references/zod-schema-templates.md` - Common Zod patterns

### Scripts
- `scripts/validate-api-surface.py` - Validate API compliance with SRM
- `scripts/generate-openapi.py` - Generate OpenAPI spec from routes

### Canonical Documents
- `docs/25-api-data/API_SURFACE_MVP.md`
- `docs/25-api-data/DTO_CATALOG.md`
- `docs/25-api-data/DTO_CANONICAL_STANDARD.md`
- `docs/20-architecture/SERVICE_RESPONSIBILITY_MATRIX.md`
