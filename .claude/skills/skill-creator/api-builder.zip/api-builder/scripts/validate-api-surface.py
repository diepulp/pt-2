#!/usr/bin/env python3
"""
Validate API surface compliance with SRM contracts.

Usage:
    python validate-api-surface.py [--service SERVICE] [--fix]

Checks:
    1. DTOs use correct pattern (A/B/C) for service type
    2. No manual interfaces in Pattern B services
    3. Cross-context imports use published DTOs only
    4. Idempotency enforcement in route handlers
    5. ServiceHttpResult envelope usage
"""

import argparse
import os
import re
import sys
from pathlib import Path
from typing import NamedTuple


class ValidationResult(NamedTuple):
    file: str
    line: int
    rule: str
    message: str
    severity: str  # 'error' | 'warning'


# Service to DTO pattern mapping
SERVICE_PATTERNS = {
    'casino': 'B',      # Canonical CRUD
    'player': 'B',      # Canonical CRUD
    'visit': 'B',       # Canonical CRUD
    'floor-layout': 'B',  # Canonical CRUD
    'rating-slip': 'C',   # Hybrid
    'loyalty': 'A',      # Contract-First
    'finance': 'A',      # Contract-First
    'mtl': 'A',          # Contract-First
    'table-context': 'A', # Contract-First
}

# SRM table ownership
SRM_OWNERSHIP = {
    'casino': ['casino', 'casino_settings', 'company', 'staff', 'game_settings', 'audit_log', 'report'],
    'player': ['player', 'player_casino'],
    'visit': ['visit'],
    'loyalty': ['player_loyalty', 'loyalty_ledger', 'loyalty_outbox'],
    'rating-slip': ['rating_slip'],
    'finance': ['player_financial_transaction', 'finance_outbox'],
    'mtl': ['mtl_entry', 'mtl_audit_note'],
    'table-context': ['gaming_table', 'gaming_table_settings', 'dealer_rotation',
                      'table_inventory_snapshot', 'table_fill', 'table_credit', 'table_drop_event'],
    'floor-layout': ['floor_layout', 'floor_layout_version', 'floor_pit',
                     'floor_table_slot', 'floor_layout_activation'],
}


def find_project_root() -> Path:
    """Find project root by looking for package.json."""
    current = Path.cwd()
    while current != current.parent:
        if (current / 'package.json').exists():
            return current
        current = current.parent
    return Path.cwd()


def get_service_from_path(file_path: str) -> str | None:
    """Extract service name from file path."""
    match = re.search(r'services/([^/]+)/', file_path)
    return match.group(1) if match else None


def check_manual_interfaces(content: str, file_path: str, service: str) -> list[ValidationResult]:
    """Check for manual interface definitions in Pattern B services."""
    results = []
    pattern = SERVICE_PATTERNS.get(service)

    if pattern != 'B':
        return results

    # Find manual interface definitions
    interface_pattern = r'export\s+interface\s+(\w*DTO\w*)\s*\{'
    for i, line in enumerate(content.split('\n'), 1):
        match = re.search(interface_pattern, line)
        if match:
            results.append(ValidationResult(
                file=file_path,
                line=i,
                rule='no-manual-interfaces',
                message=f"Manual interface '{match.group(1)}' in Pattern B service. Use 'type' with Pick/Omit.",
                severity='error'
            ))

    return results


def check_cross_context_imports(content: str, file_path: str, service: str) -> list[ValidationResult]:
    """Check for direct Database type access from non-owned tables."""
    results = []
    owned_tables = SRM_OWNERSHIP.get(service, [])

    # Find Database table access patterns
    table_pattern = r"Database\['public'\]\['Tables'\]\['(\w+)'\]"
    for i, line in enumerate(content.split('\n'), 1):
        match = re.search(table_pattern, line)
        if match:
            table_name = match.group(1)
            if table_name not in owned_tables:
                results.append(ValidationResult(
                    file=file_path,
                    line=i,
                    rule='no-cross-context-access',
                    message=f"Service '{service}' accessing table '{table_name}' (owned by another context). Use published DTO.",
                    severity='error'
                ))

    return results


def check_idempotency_enforcement(content: str, file_path: str) -> list[ValidationResult]:
    """Check that POST/PATCH/DELETE handlers enforce idempotency."""
    results = []

    # Only check route handlers
    if 'route.ts' not in file_path:
        return results

    # Find mutation handlers
    mutation_pattern = r'export\s+async\s+function\s+(POST|PATCH|DELETE)\s*\('
    idempotency_check = r"headers\.get\(['\"]x-idempotency-key['\"]|idempotency"

    lines = content.split('\n')
    for i, line in enumerate(lines, 1):
        match = re.search(mutation_pattern, line)
        if match:
            method = match.group(1)
            # Check if idempotency is enforced in the next 30 lines
            func_content = '\n'.join(lines[i-1:i+30])
            if not re.search(idempotency_check, func_content, re.IGNORECASE):
                results.append(ValidationResult(
                    file=file_path,
                    line=i,
                    rule='idempotency-required',
                    message=f"{method} handler missing idempotency key enforcement",
                    severity='error'
                ))

    return results


def check_service_http_result(content: str, file_path: str) -> list[ValidationResult]:
    """Check that route handlers use ServiceHttpResult envelope."""
    results = []

    if 'route.ts' not in file_path:
        return results

    # Check for proper response helpers
    has_response_import = re.search(r'import.*\{[^}]*(?:successResponse|errorResponse)[^}]*\}', content)
    has_next_response = re.search(r'NextResponse\.json\(', content)

    if has_next_response and not has_response_import:
        results.append(ValidationResult(
            file=file_path,
            line=1,
            rule='service-http-result',
            message="Route handler uses raw NextResponse.json instead of successResponse/errorResponse helpers",
            severity='warning'
        ))

    return results


def check_dto_documentation(content: str, file_path: str) -> list[ValidationResult]:
    """Check that DTOs have proper JSDoc documentation."""
    results = []

    if 'dtos.ts' not in file_path:
        return results

    # Find type/interface definitions without preceding JSDoc
    lines = content.split('\n')
    for i, line in enumerate(lines):
        if re.match(r'\s*export\s+(?:type|interface)\s+\w+DTO', line):
            # Check for JSDoc in previous lines
            has_jsdoc = False
            for j in range(max(0, i-10), i):
                if '/**' in lines[j]:
                    has_jsdoc = True
                    break

            if not has_jsdoc:
                dto_name = re.search(r'export\s+(?:type|interface)\s+(\w+)', line)
                results.append(ValidationResult(
                    file=file_path,
                    line=i+1,
                    rule='dto-documentation',
                    message=f"DTO '{dto_name.group(1) if dto_name else 'unknown'}' missing JSDoc with Exposure/Excludes/Owner",
                    severity='warning'
                ))

    return results


def validate_file(file_path: Path, service: str | None) -> list[ValidationResult]:
    """Validate a single file."""
    results = []

    try:
        content = file_path.read_text()
    except Exception as e:
        return [ValidationResult(
            file=str(file_path),
            line=0,
            rule='file-read',
            message=f"Could not read file: {e}",
            severity='error'
        )]

    if service:
        results.extend(check_manual_interfaces(content, str(file_path), service))
        results.extend(check_cross_context_imports(content, str(file_path), service))

    results.extend(check_idempotency_enforcement(content, str(file_path)))
    results.extend(check_service_http_result(content, str(file_path)))
    results.extend(check_dto_documentation(content, str(file_path)))

    return results


def main():
    parser = argparse.ArgumentParser(description='Validate API surface compliance')
    parser.add_argument('--service', help='Specific service to validate')
    parser.add_argument('--fix', action='store_true', help='Attempt to auto-fix issues')
    args = parser.parse_args()

    project_root = find_project_root()
    services_dir = project_root / 'services'
    api_dir = project_root / 'app' / 'api' / 'v1'

    all_results: list[ValidationResult] = []

    # Validate services
    if services_dir.exists():
        for service_dir in services_dir.iterdir():
            if service_dir.is_dir():
                service_name = service_dir.name
                if args.service and args.service != service_name:
                    continue

                for ts_file in service_dir.glob('**/*.ts'):
                    results = validate_file(ts_file, service_name)
                    all_results.extend(results)

    # Validate route handlers
    if api_dir.exists():
        for route_file in api_dir.glob('**/route.ts'):
            service = get_service_from_path(str(route_file))
            if args.service and args.service != service:
                continue

            results = validate_file(route_file, service)
            all_results.extend(results)

    # Report results
    errors = [r for r in all_results if r.severity == 'error']
    warnings = [r for r in all_results if r.severity == 'warning']

    if all_results:
        print("\n=== API Surface Validation Results ===\n")

        for result in sorted(all_results, key=lambda r: (r.file, r.line)):
            icon = '❌' if result.severity == 'error' else '⚠️'
            print(f"{icon} {result.file}:{result.line}")
            print(f"   [{result.rule}] {result.message}\n")

        print(f"\n📊 Summary: {len(errors)} errors, {len(warnings)} warnings")
    else:
        print("✅ No API surface validation issues found")

    sys.exit(1 if errors else 0)


if __name__ == '__main__':
    main()
