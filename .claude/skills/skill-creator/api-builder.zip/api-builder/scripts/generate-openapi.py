#!/usr/bin/env python3
"""
Generate OpenAPI specification from PT-2 route handlers and Zod schemas.

Usage:
    python generate-openapi.py [--output OUTPUT] [--service SERVICE]

Outputs:
    - openapi.yaml in docs/25-api-data/ (default)
    - Or specified output path
"""

import argparse
import json
import re
import sys
from pathlib import Path
from typing import Any


def find_project_root() -> Path:
    """Find project root by looking for package.json."""
    current = Path.cwd()
    while current != current.parent:
        if (current / 'package.json').exists():
            return current
        current = current.parent
    return Path.cwd()


def parse_route_path(file_path: Path, api_root: Path) -> str:
    """Convert file path to API route path."""
    relative = file_path.parent.relative_to(api_root)
    parts = []

    for part in relative.parts:
        if part.startswith('[') and part.endswith(']'):
            # Dynamic segment
            param_name = part[1:-1]
            parts.append(f'{{{param_name}}}')
        else:
            parts.append(part)

    return '/' + '/'.join(parts)


def extract_methods(content: str) -> list[str]:
    """Extract HTTP methods from route handler."""
    pattern = r'export\s+async\s+function\s+(GET|POST|PUT|PATCH|DELETE)\s*\('
    return re.findall(pattern, content)


def extract_zod_schema(content: str, schema_name: str) -> dict[str, Any] | None:
    """Extract Zod schema structure (simplified)."""
    # This is a simplified extraction - in production, use ts-morph or similar
    pattern = rf'export\s+const\s+{schema_name}\s*=\s*z\.object\(\{{([^}}]+)\}}\)'
    match = re.search(pattern, content, re.DOTALL)

    if not match:
        return None

    schema_body = match.group(1)
    properties = {}
    required = []

    # Parse field definitions (simplified)
    field_pattern = r'(\w+):\s*z\.(\w+)\(\)'
    for field_match in re.finditer(field_pattern, schema_body):
        field_name = field_match.group(1)
        field_type = field_match.group(2)

        if '.optional()' not in schema_body[field_match.start():field_match.end() + 20]:
            required.append(field_name)

        # Map Zod types to OpenAPI types
        type_map = {
            'string': {'type': 'string'},
            'number': {'type': 'number'},
            'boolean': {'type': 'boolean'},
            'array': {'type': 'array'},
            'object': {'type': 'object'},
        }

        properties[field_name] = type_map.get(field_type, {'type': 'string'})

        # Check for UUID
        if 'uuid()' in schema_body:
            properties[field_name]['format'] = 'uuid'

    return {
        'type': 'object',
        'properties': properties,
        'required': required if required else None,
    }


def generate_operation(
    method: str,
    path: str,
    service: str,
    content: str
) -> dict[str, Any]:
    """Generate OpenAPI operation object."""
    operation = {
        'tags': [service.title().replace('-', '')],
        'summary': f'{method} {path}',
        'operationId': f'{method.lower()}_{path.replace("/", "_").replace("{", "").replace("}", "")}',
        'responses': {
            '200': {
                'description': 'Successful response',
                'content': {
                    'application/json': {
                        'schema': {
                            '$ref': '#/components/schemas/ServiceHttpResult'
                        }
                    }
                }
            }
        }
    }

    # Add path parameters
    path_params = re.findall(r'\{(\w+)\}', path)
    if path_params:
        operation['parameters'] = []
        for param in path_params:
            operation['parameters'].append({
                'name': param,
                'in': 'path',
                'required': True,
                'schema': {
                    'type': 'string',
                    'format': 'uuid'
                }
            })

    # Add query parameters for GET
    if method == 'GET' and 'QuerySchema' in content:
        if 'parameters' not in operation:
            operation['parameters'] = []
        operation['parameters'].extend([
            {'name': 'cursor', 'in': 'query', 'schema': {'type': 'string'}},
            {'name': 'limit', 'in': 'query', 'schema': {'type': 'integer', 'minimum': 1, 'maximum': 100}},
        ])

    # Add request body for mutations
    if method in ['POST', 'PUT', 'PATCH']:
        operation['requestBody'] = {
            'required': True,
            'content': {
                'application/json': {
                    'schema': {
                        'type': 'object'
                    }
                }
            }
        }

    # Add idempotency header for mutations
    if method in ['POST', 'PUT', 'PATCH', 'DELETE']:
        if 'parameters' not in operation:
            operation['parameters'] = []
        operation['parameters'].append({
            'name': 'x-idempotency-key',
            'in': 'header',
            'required': True,
            'schema': {'type': 'string', 'format': 'uuid'},
            'description': 'Idempotency key for mutation deduplication'
        })

    # Add error responses
    operation['responses']['400'] = {
        'description': 'Validation error',
        'content': {
            'application/json': {
                'schema': {'$ref': '#/components/schemas/ServiceHttpResult'}
            }
        }
    }
    operation['responses']['401'] = {'description': 'Unauthorized'}
    operation['responses']['403'] = {'description': 'Forbidden'}
    operation['responses']['404'] = {'description': 'Not found'}
    operation['responses']['409'] = {'description': 'Conflict (duplicate)'}
    operation['responses']['500'] = {'description': 'Internal server error'}

    return operation


def generate_openapi_spec(project_root: Path, service_filter: str | None = None) -> dict[str, Any]:
    """Generate complete OpenAPI specification."""
    api_dir = project_root / 'app' / 'api' / 'v1'

    spec: dict[str, Any] = {
        'openapi': '3.1.0',
        'info': {
            'title': 'PT-2 API',
            'version': '1.0.0',
            'description': 'Casino Management Platform API',
            'contact': {
                'name': 'PT-2 Team'
            }
        },
        'servers': [
            {
                'url': '/api/v1',
                'description': 'API v1'
            }
        ],
        'paths': {},
        'components': {
            'schemas': {
                'ServiceHttpResult': {
                    'type': 'object',
                    'properties': {
                        'ok': {'type': 'boolean'},
                        'code': {'type': 'string'},
                        'status': {'type': 'integer'},
                        'requestId': {'type': 'string', 'format': 'uuid'},
                        'durationMs': {'type': 'number'},
                        'timestamp': {'type': 'string', 'format': 'date-time'},
                        'data': {'type': 'object'},
                        'error': {'type': 'string'},
                        'details': {'type': 'object'}
                    },
                    'required': ['ok', 'code', 'status', 'requestId', 'timestamp']
                }
            },
            'securitySchemes': {
                'bearerAuth': {
                    'type': 'http',
                    'scheme': 'bearer',
                    'bearerFormat': 'JWT'
                }
            }
        },
        'security': [
            {'bearerAuth': []}
        ]
    }

    if not api_dir.exists():
        print(f"Warning: API directory not found at {api_dir}")
        return spec

    for route_file in api_dir.glob('**/route.ts'):
        # Extract service name
        relative_path = route_file.parent.relative_to(api_dir)
        service = str(relative_path).split('/')[0]

        if service_filter and service != service_filter:
            continue

        try:
            content = route_file.read_text()
        except Exception as e:
            print(f"Warning: Could not read {route_file}: {e}")
            continue

        path = parse_route_path(route_file, api_dir)
        methods = extract_methods(content)

        if path not in spec['paths']:
            spec['paths'][path] = {}

        for method in methods:
            operation = generate_operation(method, path, service, content)
            spec['paths'][path][method.lower()] = operation

    return spec


def main():
    parser = argparse.ArgumentParser(description='Generate OpenAPI specification')
    parser.add_argument('--output', '-o', help='Output file path')
    parser.add_argument('--service', '-s', help='Filter by service name')
    parser.add_argument('--format', '-f', choices=['yaml', 'json'], default='yaml',
                        help='Output format')
    args = parser.parse_args()

    project_root = find_project_root()
    spec = generate_openapi_spec(project_root, args.service)

    # Determine output path
    if args.output:
        output_path = Path(args.output)
    else:
        output_path = project_root / 'docs' / '25-api-data' / f'openapi.{args.format}'

    # Ensure output directory exists
    output_path.parent.mkdir(parents=True, exist_ok=True)

    # Write output
    if args.format == 'yaml':
        try:
            import yaml
            content = yaml.dump(spec, default_flow_style=False, sort_keys=False, allow_unicode=True)
        except ImportError:
            print("Warning: PyYAML not installed, falling back to JSON")
            content = json.dumps(spec, indent=2)
            output_path = output_path.with_suffix('.json')
    else:
        content = json.dumps(spec, indent=2)

    output_path.write_text(content)
    print(f"✅ Generated OpenAPI spec: {output_path}")
    print(f"   Paths: {len(spec['paths'])}")
    print(f"   Operations: {sum(len(ops) for ops in spec['paths'].values())}")


if __name__ == '__main__':
    main()
