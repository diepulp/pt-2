# DTO Patterns Reference

Complete DTO pattern examples for PT-2 bounded context services.

## Pattern Overview

| Pattern | When to Use | Syntax | Mapper Required |
|---------|-------------|--------|-----------------|
| **Pattern A** | Complex bounded contexts (Loyalty, Finance, MTL, TableContext) | `interface` or `type` | ✅ Yes |
| **Pattern B** | Simple CRUD services (Player, Visit, Casino, FloorLayout) | `type` with `Pick`/`Omit` | ❌ No |
| **Pattern C** | Hybrid (RatingSlip) | Mixed | ✅ For cross-context DTOs |

---

## Pattern B: Canonical DTOs (Simple CRUD)

Use for services with direct database mapping.

### Player Service

```typescript
// services/player/dtos.ts
import type { Database } from '@/types/database.types';

/**
 * PlayerDTO - Public player profile
 *
 * Exposure: UI, external APIs
 * Excludes: birth_date (PII), internal_notes (staff-only)
 * Owner: PlayerService (SRM:149)
 */
export type PlayerDTO = Pick<
  Database['public']['Tables']['player']['Row'],
  'id' | 'first_name' | 'last_name' | 'created_at'
>;

/**
 * PlayerAdminDTO - Full player data for admin views
 *
 * Exposure: Admin UI only (role-gated)
 * Includes PII: Requires audit logging
 */
export type PlayerAdminDTO = Pick<
  Database['public']['Tables']['player']['Row'],
  'id' | 'first_name' | 'last_name' | 'birth_date' | 'created_at'
>;

export type PlayerCreateDTO = Pick<
  Database['public']['Tables']['player']['Insert'],
  'first_name' | 'last_name' | 'birth_date'
>;

export type PlayerUpdateDTO = Partial<
  Pick<
    Database['public']['Tables']['player']['Insert'],
    'first_name' | 'last_name'
  >
>;

// List response with pagination
export type PlayerListDTO = {
  items: PlayerDTO[];
  next_cursor?: string;
};
```

### Casino Service

```typescript
// services/casino/dtos.ts
import type { Database } from '@/types/database.types';

/**
 * CasinoDTO - Casino registry entry
 *
 * Exposure: UI, staff dashboards
 * Owner: CasinoService (SRM:101-147)
 */
export type CasinoDTO = Pick<
  Database['public']['Tables']['casino']['Row'],
  'id' | 'name' | 'location' | 'status' | 'address' | 'company_id' | 'created_at'
>;

export type CasinoCreateDTO = Pick<
  Database['public']['Tables']['casino']['Insert'],
  'name' | 'location' | 'company_id' | 'address' | 'status'
>;

export type CasinoUpdateDTO = Partial<CasinoCreateDTO>;

/**
 * CasinoSettingsDTO - Temporal and policy configuration
 *
 * Exposure: Admin UI only
 * Owner: CasinoService (SRM:110)
 */
export type CasinoSettingsDTO = Pick<
  Database['public']['Tables']['casino_settings']['Row'],
  'casino_id' | 'timezone' | 'gaming_day_start_time' | 'watchlist_floor' | 'ctr_threshold' | 'updated_at'
>;

export type CasinoSettingsUpdateDTO = Partial<
  Pick<
    Database['public']['Tables']['casino_settings']['Insert'],
    'timezone' | 'gaming_day_start_time' | 'watchlist_floor' | 'ctr_threshold'
  >
>;
```

### Visit Service

```typescript
// services/visit/dtos.ts
import type { Database } from '@/types/database.types';

/**
 * VisitDTO - Player visit session
 *
 * Exposure: UI, external APIs
 * Owner: VisitService (SRM:181-207)
 */
export type VisitDTO = Pick<
  Database['public']['Tables']['visit']['Row'],
  'id' | 'player_id' | 'casino_id' | 'started_at' | 'ended_at'
>;

export type VisitCreateDTO = Pick<
  Database['public']['Tables']['visit']['Insert'],
  'player_id' | 'casino_id' | 'started_at'
>;

export type VisitEndDTO = {
  ended_at?: string;
};

export type VisitListDTO = {
  items: VisitDTO[];
  next_cursor?: string;
};
```

---

## Pattern A: Contract-First DTOs (Complex Bounded Contexts)

Use for services with complex business logic requiring stable domain contracts.

### Loyalty Service

```typescript
// services/loyalty/dtos.ts

/**
 * PlayerLoyaltyDTO - Public loyalty balance
 *
 * Exposure: UI, external APIs
 * Excludes: preferences (internal-only)
 * Owner: LoyaltyService (SRM:343-373)
 */
export interface PlayerLoyaltyDTO {
  player_id: string;
  casino_id: string;
  balance: number;
  tier: string | null;
  updated_at: string;
}

/**
 * LoyaltyLedgerEntryDTO - Ledger entry for audit trail
 *
 * Exposure: Admin UI, compliance reports
 * Owner: LoyaltyService (SRM:358)
 */
export interface LoyaltyLedgerEntryDTO {
  id: string;
  casino_id: string;
  player_id: string;
  rating_slip_id: string | null;
  visit_id: string | null;
  staff_id: string | null;
  points_earned: number;
  reason: 'mid_session' | 'session_end' | 'manual_adjustment' | 'promotion' | 'correction';
  idempotency_key: string | null;
  average_bet: number | null;
  duration_seconds: number | null;
  game_type: 'blackjack' | 'poker' | 'roulette' | 'baccarat' | null;
  created_at: string;
}

/**
 * MidSessionRewardInput - Issue reward during active session
 *
 * Owner: LoyaltyService (SRM:360)
 */
export interface MidSessionRewardInput {
  casino_id: string;
  player_id: string;
  rating_slip_id: string;
  staff_id: string;
  points: number;
  reason?: 'mid_session' | 'session_end' | 'manual_adjustment' | 'promotion' | 'correction';
  idempotency_key?: string;
}

export interface MidSessionRewardResult {
  ledger_id: string;
  balance_after: number;
}

export interface LoyaltyLedgerListDTO {
  items: LoyaltyLedgerEntryDTO[];
  next_cursor?: string;
}
```

### Loyalty Mappers (Required for Pattern A)

```typescript
// services/loyalty/mappers.ts
import type { Database } from '@/types/database.types';
import type { PlayerLoyaltyDTO, LoyaltyLedgerEntryDTO } from './dtos';

type LoyaltyRow = Database['public']['Tables']['player_loyalty']['Row'];
type LedgerRow = Database['public']['Tables']['loyalty_ledger']['Row'];

export function toPlayerLoyaltyDTO(row: LoyaltyRow): PlayerLoyaltyDTO {
  return {
    player_id: row.player_id,
    casino_id: row.casino_id,
    balance: row.balance,
    tier: row.tier,
    updated_at: row.updated_at,
    // Explicitly omit: preferences (internal field)
  };
}

export function toLoyaltyLedgerEntryDTO(row: LedgerRow): LoyaltyLedgerEntryDTO {
  return {
    id: row.id,
    casino_id: row.casino_id,
    player_id: row.player_id,
    rating_slip_id: row.rating_slip_id,
    visit_id: row.visit_id,
    staff_id: row.staff_id,
    points_earned: row.points_earned,
    reason: row.reason as LoyaltyLedgerEntryDTO['reason'],
    idempotency_key: row.idempotency_key,
    average_bet: row.average_bet,
    duration_seconds: row.duration_seconds,
    game_type: row.game_type as LoyaltyLedgerEntryDTO['game_type'],
    created_at: row.created_at,
  };
}
```

### Finance Service

```typescript
// services/finance/dtos.ts

/**
 * FinancialTransactionDTO - Financial ledger entry
 *
 * Exposure: Admin UI, compliance reports
 * Owner: PlayerFinancialService (SRM:303-341)
 */
export interface FinancialTransactionDTO {
  id: string;
  casino_id: string;
  player_id: string;
  visit_id: string | null;
  rating_slip_id: string | null;
  amount: number;
  tender_type: string | null;
  created_at: string;
  gaming_day: string | null;
}

export interface FinancialTransactionCreateInput {
  casino_id: string;
  player_id: string;
  amount: number;
  tender_type?: string;
  visit_id?: string;
  rating_slip_id?: string;
  created_at?: string;
}

export interface FinancialTransactionListDTO {
  items: FinancialTransactionDTO[];
  next_cursor?: string;
}
```

### MTL Service

```typescript
// services/mtl/dtos.ts

/**
 * MtlEntryDTO - Multiple Transaction Log entry
 *
 * Exposure: Compliance UI only
 * Owner: MTLService (SRM:375-423)
 */
export interface MtlEntryDTO {
  id: string;
  casino_id: string;
  patron_uuid: string;
  staff_id: string | null;
  rating_slip_id: string | null;
  visit_id: string | null;
  amount: number;
  direction: 'in' | 'out';
  area: string | null;
  created_at: string;
  idempotency_key: string | null;
}

export interface MtlEntryCreateInput {
  casino_id: string;
  patron_uuid: string;
  staff_id?: string;
  rating_slip_id?: string;
  visit_id?: string;
  amount: number;
  direction: 'in' | 'out';
  area?: string;
  idempotency_key?: string;
  created_at?: string;
}

export interface MtlAuditNoteDTO {
  id: string;
  mtl_entry_id: string;
  staff_id: string | null;
  note: string;
  created_at: string;
}

export interface MtlAuditNoteCreateInput {
  staff_id: string;
  note: string;
}

export interface MtlEntryListDTO {
  items: MtlEntryDTO[];
  next_cursor?: string;
}
```

### TableContext Service

```typescript
// services/table-context/dtos.ts

/**
 * GamingTableDTO - Table configuration
 *
 * Exposure: UI, floor management
 * Owner: TableContextService (SRM:209-259)
 */
export interface GamingTableDTO {
  id: string;
  casino_id: string;
  label: string;
  pit: string | null;
  type: 'blackjack' | 'poker' | 'roulette' | 'baccarat';
  status: 'inactive' | 'active' | 'closed';
  created_at: string;
}

export interface DealerRotationDTO {
  id: string;
  casino_id: string;
  table_id: string;
  staff_id: string | null;
  started_at: string;
  ended_at: string | null;
}

export interface TableInventorySnapshotDTO {
  id: string;
  casino_id: string;
  table_id: string;
  snapshot_type: 'open' | 'close' | 'rundown';
  chipset: Record<string, number>;
  counted_by: string | null;
  verified_by: string | null;
  discrepancy_cents: number;
  note: string | null;
  created_at: string;
}

export interface TableFillDTO {
  id: string;
  casino_id: string;
  table_id: string;
  chipset: Record<string, number>;
  amount_cents: number;
  requested_by: string | null;
  delivered_by: string | null;
  received_by: string | null;
  slip_no: string | null;
  request_id: string | null;
  created_at: string;
}

export interface TableCreditDTO {
  id: string;
  casino_id: string;
  table_id: string;
  chipset: Record<string, number>;
  amount_cents: number;
  authorized_by: string | null;
  sent_by: string | null;
  received_by: string | null;
  slip_no: string | null;
  request_id: string | null;
  created_at: string;
}

export interface TableListDTO {
  items: GamingTableDTO[];
  next_cursor?: string;
}
```

---

## Pattern C: Hybrid DTOs (Mixed Contexts)

Use for services that need both database-bound and cross-context DTOs.

### RatingSlip Service

```typescript
// services/rating-slip/dtos.ts
import type { Database } from '@/types/database.types';

/**
 * RatingSlipDTO - Telemetry session
 *
 * Exposure: UI, external APIs
 * Owner: RatingSlipService (SRM:261-301)
 */
export type RatingSlipDTO = Pick<
  Database['public']['Tables']['rating_slip']['Row'],
  | 'id'
  | 'player_id'
  | 'casino_id'
  | 'visit_id'
  | 'table_id'
  | 'game_settings'
  | 'average_bet'
  | 'start_time'
  | 'end_time'
  | 'status'
  | 'policy_snapshot'
>;

export type RatingSlipCreateDTO = Pick<
  Database['public']['Tables']['rating_slip']['Insert'],
  'player_id' | 'casino_id' | 'visit_id' | 'table_id' | 'game_settings' | 'average_bet' | 'policy_snapshot'
>;

export type RatingSlipUpdateDTO = Partial<
  Pick<
    Database['public']['Tables']['rating_slip']['Insert'],
    'average_bet' | 'end_time' | 'status' | 'policy_snapshot'
  >
>;

/**
 * RatingSlipTelemetryDTO - Published for cross-context consumers
 *
 * Consumers: LoyaltyService, PlayerFinancialService
 * Published via: DTO import (not direct DB access)
 */
export interface RatingSlipTelemetryDTO {
  id: string;
  player_id: string;
  casino_id: string;
  average_bet: number | null;
  duration_seconds: number;
  game_type: 'blackjack' | 'poker' | 'roulette' | 'baccarat';
}

export type RatingSlipListDTO = {
  items: RatingSlipDTO[];
  next_cursor?: string;
};
```

---

## Anti-Patterns (DO NOT USE)

### ❌ Manual Interface for Pattern B

```typescript
// ❌ BANNED: Manual interface for CRUD service
export interface PlayerCreateDTO {
  first_name: string;
  last_name: string;
  birth_date?: string;
}

// ✅ USE THIS: Derived from Database types
export type PlayerCreateDTO = Pick<
  Database['public']['Tables']['player']['Insert'],
  'first_name' | 'last_name' | 'birth_date'
>;
```

### ❌ Cross-Context Database Access

```typescript
// ❌ BANNED: Loyalty accessing RatingSlip table directly
// services/loyalty/telemetry.ts
import type { Database } from '@/types/database.types';
type RatingSlipData = Database['public']['Tables']['rating_slip']['Row'];

// ✅ USE THIS: Import published DTO from owning service
import type { RatingSlipTelemetryDTO } from '@/services/rating-slip/dtos';
```

### ❌ Leaking PII Fields

```typescript
// ❌ BANNED: Exposing sensitive fields
export type PlayerDTO = Pick<
  Database['public']['Tables']['player']['Row'],
  'id' | 'first_name' | 'ssn' | 'internal_notes'  // ❌ PII + internal fields
>;

// ✅ USE THIS: Explicit field allowlist
export type PlayerDTO = Pick<
  Database['public']['Tables']['player']['Row'],
  'id' | 'first_name' | 'last_name' | 'created_at'  // ✅ Safe fields only
>;
```

---

## DTO Documentation Template

Every DTO MUST include JSDoc documentation:

```typescript
/**
 * [DTOName] - [Brief description]
 *
 * Exposure: [UI, external APIs, Admin UI, Compliance, etc.]
 * Excludes: [List of excluded fields with reasons]
 * Owner: [ServiceName] (SRM:[line reference])
 */
export type DTOName = ...
```
