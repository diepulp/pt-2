# Zod Schema Templates Reference

Common Zod schema patterns for PT-2 API validation.

## Common Field Schemas

### UUID Fields

```typescript
import { z } from 'zod';

// Required UUID
export const uuidSchema = z.string().uuid();

// Optional UUID
export const optionalUuidSchema = z.string().uuid().optional();

// Nullable UUID
export const nullableUuidSchema = z.string().uuid().nullable();
```

### String Fields

```typescript
// Required non-empty string
export const requiredStringSchema = z.string().min(1);

// Optional string
export const optionalStringSchema = z.string().optional();

// String with max length
export const limitedStringSchema = z.string().max(500);

// Email
export const emailSchema = z.string().email();

// Regex pattern (e.g., time format)
export const timeSchema = z.string().regex(/^\d{2}:\d{2}$/);
```

### Number Fields

```typescript
// Positive integer
export const positiveIntSchema = z.number().int().positive();

// Non-negative integer
export const nonNegativeIntSchema = z.number().int().nonnegative();

// Number with min/max
export const boundedNumberSchema = z.number().min(0).max(100);

// Amount in cents (always integer)
export const amountCentsSchema = z.number().int().positive();
```

### Date/Time Fields

```typescript
// ISO date string
export const dateStringSchema = z.string();

// Date with validation
export const validDateSchema = z.string().refine(
  (val) => !isNaN(Date.parse(val)),
  { message: 'Invalid date format' }
);

// Optional date
export const optionalDateSchema = z.string().optional();
```

### Enum Fields

```typescript
// Status enum
export const statusSchema = z.enum(['active', 'inactive']);

// Role enum
export const roleSchema = z.enum(['dealer', 'pit_boss', 'admin']);

// Game type enum
export const gameTypeSchema = z.enum(['blackjack', 'poker', 'roulette', 'baccarat']);

// Direction enum
export const directionSchema = z.enum(['in', 'out']);
```

### JSON/Record Fields

```typescript
// Generic record
export const recordSchema = z.record(z.any());

// Typed record (chipset)
export const chipsetSchema = z.record(z.string(), z.number().int().nonnegative());

// JSON with nullable
export const nullableJsonSchema = z.record(z.any()).nullable();
```

---

## Request Parameter Schemas

### Detail/Single Resource

```typescript
// Standard detail params
export const DetailParamsSchema = z.object({
  id: z.string().uuid(),
});

// Named resource params
export const PlayerDetailParamsSchema = z.object({
  player_id: z.string().uuid(),
});

export const CasinoDetailParamsSchema = z.object({
  casino_id: z.string().uuid(),
});

// Nested resource params
export const RatingSlipDetailParamsSchema = z.object({
  visit_id: z.string().uuid(),
  rating_slip_id: z.string().uuid(),
});
```

### List/Query Parameters

```typescript
// Standard list query with pagination
export const ListQuerySchema = z.object({
  casino_id: z.string().uuid(),
  status: z.enum(['active', 'inactive']).optional(),
  cursor: z.string().optional(),
  limit: z.number().int().min(1).max(100).optional(),
});

// Search query
export const SearchQuerySchema = z.object({
  casino_id: z.string().uuid(),
  q: z.string().optional(),
  cursor: z.string().optional(),
  limit: z.number().int().min(1).max(100).optional(),
});

// Date-filtered query
export const DateFilteredQuerySchema = z.object({
  casino_id: z.string().uuid(),
  gaming_day: z.string().optional(),
  cursor: z.string().optional(),
  limit: z.number().int().min(1).max(100).optional(),
});

// Amount-filtered query (MTL)
export const AmountFilteredQuerySchema = z.object({
  casino_id: z.string().uuid(),
  min_amount: z.number().optional(),
  cursor: z.string().optional(),
  limit: z.number().int().min(1).max(100).optional(),
});
```

---

## Request Body Schemas

### Create Schemas

```typescript
// Player create
export const PlayerCreateSchema = z.object({
  first_name: z.string().min(1),
  last_name: z.string().min(1),
  birth_date: z.string().optional(),
  casino_enrollment: z
    .object({
      casino_id: z.string().uuid(),
      status: z.enum(['active', 'inactive']).default('active'),
    })
    .optional(),
});

// Visit create
export const VisitCreateSchema = z.object({
  player_id: z.string().uuid(),
  casino_id: z.string().uuid(),
  started_at: z.string().optional(),
});

// Rating slip create
export const RatingSlipCreateSchema = z.object({
  player_id: z.string().uuid(),
  casino_id: z.string().uuid(),
  visit_id: z.string().uuid().optional(),
  table_id: z.string().uuid().optional(),
  game_settings: z.record(z.any()).nullable().optional(),
  average_bet: z.number().min(0).nullable().optional(),
  policy_snapshot: z.record(z.any()).nullable().optional(),
});

// Table inventory snapshot create
export const TableInventorySnapshotCreateSchema = z.object({
  casino_id: z.string().uuid(),
  table_id: z.string().uuid(),
  snapshot_type: z.enum(['open', 'close', 'rundown']),
  chipset: z.record(z.string(), z.number().int().nonnegative()),
  counted_by: z.string().uuid().optional(),
  verified_by: z.string().uuid().optional(),
  discrepancy_cents: z.number().int().optional(),
  note: z.string().max(500).optional(),
});

// Financial transaction create
export const FinancialTxnCreateSchema = z.object({
  casino_id: z.string().uuid(),
  player_id: z.string().uuid(),
  amount: z.number(),
  tender_type: z.string().optional(),
  visit_id: z.string().uuid().optional(),
  rating_slip_id: z.string().uuid().optional(),
  created_at: z.string().optional(),
});

// MTL entry create
export const MtlEntryCreateSchema = z.object({
  casino_id: z.string().uuid(),
  patron_uuid: z.string().uuid(),
  staff_id: z.string().uuid().optional(),
  rating_slip_id: z.string().uuid().optional(),
  visit_id: z.string().uuid().optional(),
  amount: z.number(),
  direction: z.enum(['in', 'out']),
  area: z.string().optional(),
  idempotency_key: z.string().optional(),
  created_at: z.string().optional(),
});
```

### Update Schemas

```typescript
// Partial update (from create schema)
export const PlayerUpdateSchema = PlayerCreateSchema.partial();

// Explicit update schema
export const CasinoSettingsUpdateSchema = z.object({
  timezone: z.string().optional(),
  gaming_day_start_time: z.string().regex(/^\d{2}:\d{2}$/).optional(),
  watchlist_floor: z.number().min(0).optional(),
  ctr_threshold: z.number().min(0).optional(),
});

// Rating slip update
export const RatingSlipUpdateSchema = z.object({
  average_bet: z.number().min(0).nullable().optional(),
  end_time: z.string().optional(),
  status: z.enum(['open', 'paused', 'closed']).optional(),
  policy_snapshot: z.record(z.any()).nullable().optional(),
});
```

### Action Schemas

```typescript
// Close/End schemas
export const VisitEndSchema = z.object({
  ended_at: z.string().optional(),
});

export const RatingSlipCloseSchema = z.object({
  end_time: z.string().optional(),
});

// Loyalty reward
export const MidSessionRewardSchema = z.object({
  casino_id: z.string().uuid(),
  player_id: z.string().uuid(),
  rating_slip_id: z.string().uuid(),
  staff_id: z.string().uuid(),
  points: z.number().int().positive(),
  reason: z.enum([
    'mid_session',
    'session_end',
    'manual_adjustment',
    'promotion',
    'correction',
  ]).optional(),
  idempotency_key: z.string().optional(),
});

// Audit note
export const MtlAuditNoteCreateSchema = z.object({
  staff_id: z.string().uuid(),
  note: z.string().min(1),
});
```

---

## Response Schemas

### Single Resource Response

```typescript
// Player response
export const PlayerSchema = z.object({
  id: z.string().uuid(),
  first_name: z.string(),
  last_name: z.string(),
  birth_date: z.string().nullable(),
  created_at: z.string(),
});

// Casino response
export const CasinoSchema = z.object({
  id: z.string().uuid(),
  name: z.string(),
  location: z.string().nullable(),
  status: z.string(),
  address: z.record(z.any()).nullable(),
  company_id: z.string().uuid().nullable(),
  created_at: z.string(),
});

// Visit response
export const VisitSchema = z.object({
  id: z.string().uuid(),
  player_id: z.string().uuid(),
  casino_id: z.string().uuid(),
  started_at: z.string(),
  ended_at: z.string().nullable(),
});
```

### List Response

```typescript
// Standard list response
export const PlayerListResponseSchema = z.object({
  items: z.array(PlayerSchema),
  next_cursor: z.string().optional(),
});

export const VisitListResponseSchema = z.object({
  items: z.array(VisitSchema),
  next_cursor: z.string().optional(),
});
```

### Action Response

```typescript
// Reward result
export const MidSessionRewardResultSchema = z.object({
  ledger_id: z.string().uuid(),
  balance_after: z.number().int(),
});

// Delete result
export const DeleteResultSchema = z.object({
  deleted: z.boolean(),
});
```

---

## Complex Type Patterns

### Discriminated Unions

```typescript
// Event type with discriminator
export const DomainEventSchema = z.discriminatedUnion('event', [
  z.object({
    event: z.literal('rating_slip.updated'),
    rating_slip_id: z.string().uuid(),
    player_id: z.string().uuid(),
    casino_id: z.string().uuid(),
    average_bet: z.number(),
    at: z.string(),
  }),
  z.object({
    event: z.literal('loyalty.ledger_appended'),
    ledger_id: z.string().uuid(),
    player_id: z.string().uuid(),
    points: z.number(),
    at: z.string(),
  }),
]);
```

### Conditional Fields

```typescript
// Table context custody event
export const CustodyEventSchema = z.object({
  casino_id: z.string().uuid(),
  table_id: z.string().uuid(),
  chipset: z.record(z.string(), z.number().int().nonnegative()),
  amount_cents: z.number().int().positive(),
  // Conditional staff fields
  requested_by: z.string().uuid(),
  delivered_by: z.string().uuid(),
  received_by: z.string().uuid(),
  slip_no: z.string().max(64).optional(),
  request_id: z.string().uuid().optional(),
});
```

### Nested Objects

```typescript
// Floor layout with nested pits and slots
export const FloorLayoutCreateSchema = z.object({
  casino_id: z.string().uuid(),
  name: z.string().min(1),
  description: z.string().optional(),
  pits: z.array(
    z.object({
      name: z.string(),
      coordinates: z.object({
        x: z.number(),
        y: z.number(),
        width: z.number(),
        height: z.number(),
      }),
      slots: z.array(
        z.object({
          table_id: z.string().uuid(),
          position: z.number().int(),
          coordinates: z.object({
            x: z.number(),
            y: z.number(),
          }),
        })
      ),
    })
  ).optional(),
});
```

---

## Validation Utilities

### Custom Refinements

```typescript
// Date must be in past
export const pastDateSchema = z.string().refine(
  (val) => new Date(val) < new Date(),
  { message: 'Date must be in the past' }
);

// Amount must be positive cents
export const positiveCentsSchema = z.number().int().positive().refine(
  (val) => val % 1 === 0,
  { message: 'Amount must be whole cents' }
);

// Gaming day format
export const gamingDaySchema = z.string().regex(
  /^\d{4}-\d{2}-\d{2}$/,
  { message: 'Gaming day must be YYYY-MM-DD format' }
);
```

### Transform and Preprocess

```typescript
// String to number transform
export const numericStringSchema = z.preprocess(
  (val) => (typeof val === 'string' ? Number(val) : val),
  z.number()
);

// Trim whitespace
export const trimmedStringSchema = z.string().transform((s) => s.trim());

// Default value
export const statusWithDefaultSchema = z.enum(['active', 'inactive']).default('active');
```

### Coercion

```typescript
// Coerce query params to proper types
export const CoercedQuerySchema = z.object({
  casino_id: z.string().uuid(),
  limit: z.coerce.number().int().min(1).max(100).optional(),
  offset: z.coerce.number().int().min(0).optional(),
});
```
