# API Surface Patterns Reference

Complete route handler templates and patterns for PT-2 API implementation.

## Route Handler Templates

### Standard GET (Single Resource)

```typescript
// app/api/v1/[domain]/[id]/route.ts
import { NextRequest } from 'next/server';
import { createClient } from '@/lib/supabase/server';
import { createDomainService } from '@/services/domain';
import { DomainDetailParamsSchema } from '@/services/domain/schemas';
import { successResponse, errorResponse } from '@/lib/http/service-response';

export async function GET(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  const { id } = await params;

  const parseResult = DomainDetailParamsSchema.safeParse({ id });
  if (!parseResult.success) {
    return errorResponse({
      code: 'VALIDATION_ERROR',
      message: 'Invalid resource ID',
      details: parseResult.error.issues,
      status: 400,
    });
  }

  const supabase = await createClient();
  const service = createDomainService(supabase);
  const result = await service.getById(id);

  return result.success
    ? successResponse(result)
    : errorResponse(result);
}
```

### Standard GET (List with Pagination)

```typescript
// app/api/v1/[domain]/route.ts
import { NextRequest } from 'next/server';
import { createClient } from '@/lib/supabase/server';
import { createDomainService } from '@/services/domain';
import { DomainListQuerySchema } from '@/services/domain/schemas';
import { successResponse, errorResponse } from '@/lib/http/service-response';

export async function GET(request: NextRequest) {
  const { searchParams } = new URL(request.url);

  const queryResult = DomainListQuerySchema.safeParse({
    casino_id: searchParams.get('casino_id'),
    status: searchParams.get('status'),
    cursor: searchParams.get('cursor'),
    limit: searchParams.get('limit') ? Number(searchParams.get('limit')) : undefined,
  });

  if (!queryResult.success) {
    return errorResponse({
      code: 'VALIDATION_ERROR',
      message: 'Invalid query parameters',
      details: queryResult.error.issues,
      status: 400,
    });
  }

  const supabase = await createClient();
  const service = createDomainService(supabase);
  const result = await service.list(queryResult.data);

  return result.success
    ? successResponse(result)
    : errorResponse(result);
}
```

### Standard POST (Create with Idempotency)

```typescript
// app/api/v1/[domain]/route.ts
import { NextRequest } from 'next/server';
import { createClient } from '@/lib/supabase/server';
import { createDomainService } from '@/services/domain';
import { DomainCreateSchema } from '@/services/domain/schemas';
import { successResponse, errorResponse } from '@/lib/http/service-response';

export async function POST(request: NextRequest) {
  // Enforce idempotency
  const idempotencyKey = request.headers.get('x-idempotency-key');
  if (!idempotencyKey) {
    return errorResponse({
      code: 'IDEMPOTENCY_KEY_REQUIRED',
      message: 'x-idempotency-key header is required for mutations',
      status: 400,
    });
  }

  let body: unknown;
  try {
    body = await request.json();
  } catch {
    return errorResponse({
      code: 'VALIDATION_ERROR',
      message: 'Invalid JSON body',
      status: 400,
    });
  }

  const parseResult = DomainCreateSchema.safeParse(body);
  if (!parseResult.success) {
    return errorResponse({
      code: 'VALIDATION_ERROR',
      message: 'Invalid request body',
      details: parseResult.error.issues,
      status: 400,
    });
  }

  const supabase = await createClient();
  const service = createDomainService(supabase);
  const result = await service.create(parseResult.data, { idempotencyKey });

  return result.success
    ? successResponse(result, 201)
    : errorResponse(result);
}
```

### Standard PATCH (Update)

```typescript
// app/api/v1/[domain]/[id]/route.ts
import { NextRequest } from 'next/server';
import { createClient } from '@/lib/supabase/server';
import { createDomainService } from '@/services/domain';
import { DomainUpdateSchema, DomainDetailParamsSchema } from '@/services/domain/schemas';
import { successResponse, errorResponse } from '@/lib/http/service-response';

export async function PATCH(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  const { id } = await params;

  // Enforce idempotency
  const idempotencyKey = request.headers.get('x-idempotency-key');
  if (!idempotencyKey) {
    return errorResponse({
      code: 'IDEMPOTENCY_KEY_REQUIRED',
      message: 'x-idempotency-key header is required for mutations',
      status: 400,
    });
  }

  const paramsResult = DomainDetailParamsSchema.safeParse({ id });
  if (!paramsResult.success) {
    return errorResponse({
      code: 'VALIDATION_ERROR',
      message: 'Invalid resource ID',
      details: paramsResult.error.issues,
      status: 400,
    });
  }

  let body: unknown;
  try {
    body = await request.json();
  } catch {
    return errorResponse({
      code: 'VALIDATION_ERROR',
      message: 'Invalid JSON body',
      status: 400,
    });
  }

  const bodyResult = DomainUpdateSchema.safeParse(body);
  if (!bodyResult.success) {
    return errorResponse({
      code: 'VALIDATION_ERROR',
      message: 'Invalid request body',
      details: bodyResult.error.issues,
      status: 400,
    });
  }

  const supabase = await createClient();
  const service = createDomainService(supabase);
  const result = await service.update(id, bodyResult.data, { idempotencyKey });

  return result.success
    ? successResponse(result)
    : errorResponse(result);
}
```

### Standard DELETE

```typescript
// app/api/v1/[domain]/[id]/route.ts
import { NextRequest } from 'next/server';
import { createClient } from '@/lib/supabase/server';
import { createDomainService } from '@/services/domain';
import { DomainDetailParamsSchema } from '@/services/domain/schemas';
import { successResponse, errorResponse } from '@/lib/http/service-response';

export async function DELETE(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  const { id } = await params;

  // Enforce idempotency
  const idempotencyKey = request.headers.get('x-idempotency-key');
  if (!idempotencyKey) {
    return errorResponse({
      code: 'IDEMPOTENCY_KEY_REQUIRED',
      message: 'x-idempotency-key header is required for mutations',
      status: 400,
    });
  }

  const parseResult = DomainDetailParamsSchema.safeParse({ id });
  if (!parseResult.success) {
    return errorResponse({
      code: 'VALIDATION_ERROR',
      message: 'Invalid resource ID',
      details: parseResult.error.issues,
      status: 400,
    });
  }

  const supabase = await createClient();
  const service = createDomainService(supabase);
  const result = await service.delete(id, { idempotencyKey });

  return result.success
    ? successResponse({ deleted: true }, 200)
    : errorResponse(result);
}
```

---

## Server Action Templates

### Standard Form Action

```typescript
// app/actions/domain.ts
'use server';

import { createClient } from '@/lib/supabase/server';
import { createDomainService } from '@/services/domain';
import { DomainCreateSchema } from '@/services/domain/schemas';
import { withServerAction } from '@/lib/action/with-server-action';
import type { ServiceResult } from '@/lib/types/service-result';

export async function createDomainAction(
  formData: FormData
): Promise<ServiceResult<DomainDTO>> {
  return withServerAction(async ({ requestId, actor }) => {
    const input = Object.fromEntries(formData);
    const parseResult = DomainCreateSchema.safeParse(input);

    if (!parseResult.success) {
      return {
        success: false,
        data: null,
        error: {
          code: 'VALIDATION_ERROR',
          message: parseResult.error.issues[0].message,
          details: parseResult.error.issues,
        },
        requestId,
        timestamp: new Date().toISOString(),
      };
    }

    const supabase = await createClient();
    const service = createDomainService(supabase);

    return service.create(parseResult.data, {
      requestId,
      actorId: actor.id,
    });
  });
}
```

### Action with Optimistic Update Support

```typescript
// app/actions/domain.ts
'use server';

import { createClient } from '@/lib/supabase/server';
import { createDomainService } from '@/services/domain';
import { revalidatePath } from 'next/cache';
import type { ServiceResult } from '@/lib/types/service-result';

export async function updateDomainAction(
  id: string,
  updates: DomainUpdateDTO
): Promise<ServiceResult<DomainDTO>> {
  const supabase = await createClient();
  const service = createDomainService(supabase);
  const result = await service.update(id, updates);

  if (result.success) {
    // Revalidate after successful mutation
    revalidatePath(`/domain/${id}`);
    revalidatePath('/domain');
  }

  return result;
}
```

---

## HTTP Fetcher Templates

### Standard CRUD Fetchers

```typescript
// services/domain/http.ts
import { fetchJSON } from '@/lib/http/fetch-json';
import type {
  DomainDTO,
  DomainCreateDTO,
  DomainUpdateDTO,
  DomainListDTO,
} from './dtos';

const API_BASE = '/api/v1/domain';

export async function getDomain(id: string): Promise<DomainDTO> {
  return fetchJSON(`${API_BASE}/${id}`);
}

export async function listDomains(params: {
  casinoId: string;
  cursor?: string;
  limit?: number;
}): Promise<DomainListDTO> {
  const searchParams = new URLSearchParams({
    casino_id: params.casinoId,
    ...(params.cursor && { cursor: params.cursor }),
    ...(params.limit && { limit: String(params.limit) }),
  });
  return fetchJSON(`${API_BASE}?${searchParams}`);
}

export async function createDomain(input: DomainCreateDTO): Promise<DomainDTO> {
  return fetchJSON(API_BASE, {
    method: 'POST',
    headers: {
      'content-type': 'application/json',
      'x-idempotency-key': crypto.randomUUID(),
    },
    body: JSON.stringify(input),
  });
}

export async function updateDomain(
  id: string,
  input: DomainUpdateDTO
): Promise<DomainDTO> {
  return fetchJSON(`${API_BASE}/${id}`, {
    method: 'PATCH',
    headers: {
      'content-type': 'application/json',
      'x-idempotency-key': crypto.randomUUID(),
    },
    body: JSON.stringify(input),
  });
}

export async function deleteDomain(id: string): Promise<void> {
  return fetchJSON(`${API_BASE}/${id}`, {
    method: 'DELETE',
    headers: {
      'x-idempotency-key': crypto.randomUUID(),
    },
  });
}
```

---

## Query Key Factory Template

```typescript
// services/domain/keys.ts
type DomainListFilters = {
  status?: 'active' | 'inactive';
  casinoId?: string;
  q?: string;
};

const serialize = (filters: DomainListFilters = {}) =>
  JSON.stringify(
    Object.keys(filters)
      .sort()
      .map((key) => [key, filters[key as keyof DomainListFilters]])
  );

export const domainKeys = {
  root: ['domain'] as const,

  list: Object.assign(
    (filters: DomainListFilters = {}) =>
      [...domainKeys.root, 'list', serialize(filters)] as const,
    {
      scope: [...domainKeys.root, 'list'] as const,
    }
  ),

  detail: (id: string) => [...domainKeys.root, 'detail', id] as const,

  create: () => [...domainKeys.root, 'create'] as const,

  update: (id: string) => [...domainKeys.root, 'update', id] as const,

  delete: (id: string) => [...domainKeys.root, 'delete', id] as const,
};
```

---

## React Query Hook Template

```typescript
// hooks/use-domain.ts
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { domainKeys } from '@/services/domain/keys';
import {
  getDomain,
  listDomains,
  createDomain,
  updateDomain,
  deleteDomain,
} from '@/services/domain/http';
import type { DomainDTO, DomainCreateDTO, DomainUpdateDTO } from '@/services/domain/dtos';

export function useDomain(id: string) {
  return useQuery({
    queryKey: domainKeys.detail(id),
    queryFn: () => getDomain(id),
    enabled: !!id,
  });
}

export function useDomains(filters: { casinoId: string }) {
  return useQuery({
    queryKey: domainKeys.list(filters),
    queryFn: () => listDomains(filters),
  });
}

export function useCreateDomain() {
  const queryClient = useQueryClient();

  return useMutation({
    mutationKey: domainKeys.create(),
    mutationFn: (input: DomainCreateDTO) => createDomain(input),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: domainKeys.list.scope });
    },
  });
}

export function useUpdateDomain(id: string) {
  const queryClient = useQueryClient();

  return useMutation({
    mutationKey: domainKeys.update(id),
    mutationFn: (input: DomainUpdateDTO) => updateDomain(id, input),
    onSuccess: (data) => {
      queryClient.setQueryData(domainKeys.detail(id), data);
      queryClient.invalidateQueries({ queryKey: domainKeys.list.scope });
    },
  });
}

export function useDeleteDomain(id: string) {
  const queryClient = useQueryClient();

  return useMutation({
    mutationKey: domainKeys.delete(id),
    mutationFn: () => deleteDomain(id),
    onSuccess: () => {
      queryClient.removeQueries({ queryKey: domainKeys.detail(id) });
      queryClient.invalidateQueries({ queryKey: domainKeys.list.scope });
    },
  });
}
```

---

## Rate Limiting Implementation

```typescript
// app/api/v1/[domain]/route.ts
import { rateLimit } from '@/lib/rate-limiter';

export async function POST(request: NextRequest) {
  // Apply rate limit (10 writes/min per staff)
  const rateLimitResult = await rateLimit(request, {
    limit: 10,
    window: 60,
    identifier: 'staff_id',
  });

  if (!rateLimitResult.success) {
    return errorResponse({
      code: 'RATE_LIMITED',
      message: 'Too many requests',
      status: 429,
    });
  }

  // Continue with normal flow...
}
```

---

## Cursor Pagination Implementation

```typescript
// Encode cursor
function encodeCursor(createdAt: string, id: string): string {
  return Buffer.from(JSON.stringify([createdAt, id])).toString('base64');
}

// Decode cursor
function decodeCursor(cursor: string): [string, string] {
  return JSON.parse(Buffer.from(cursor, 'base64').toString());
}

// Service implementation
async list(params: ListParams) {
  let query = this.supabase
    .from('table')
    .select('*')
    .eq('casino_id', params.casinoId)
    .order('created_at', { ascending: false })
    .order('id', { ascending: false })
    .limit((params.limit ?? 20) + 1); // Fetch one extra for next cursor

  if (params.cursor) {
    const [createdAt, id] = decodeCursor(params.cursor);
    query = query.or(`created_at.lt.${createdAt},and(created_at.eq.${createdAt},id.lt.${id})`);
  }

  const { data, error } = await query;

  if (error) throw error;

  const hasMore = data.length > (params.limit ?? 20);
  const items = hasMore ? data.slice(0, -1) : data;
  const nextCursor = hasMore
    ? encodeCursor(items[items.length - 1].created_at, items[items.length - 1].id)
    : undefined;

  return { items, next_cursor: nextCursor };
}
```
